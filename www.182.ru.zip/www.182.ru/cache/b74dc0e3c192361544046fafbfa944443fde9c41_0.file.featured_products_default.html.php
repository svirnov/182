<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:27
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\featured_products_default.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fb57bcf9_76833634',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b74dc0e3c192361544046fafbfa944443fde9c41' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\featured_products_default.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fb57bcf9_76833634 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_vam_truncate')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins_vam\\modifier.vam_truncate.php';
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "featured", 0);
?>
 

<?php echo '<script'; ?>
 type="text/javascript" src="jscript/jquery/plugins/sequence/sequence.jquery-min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="jscript/jquery/plugins/sequence/sequencejs-options.js"><?php echo '</script'; ?>
>

<div class="page">
<div class="pageItem">

<div id="slider">
	<div id="sequence-theme">
		<div id="sequence">
			<div class="prev"><i class="fa fa-chevron-left"></i></div>
			<div class="next"><i class="fa fa-chevron-right"></i></div>
				<ul>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_content']->value, 'module_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['module_data']->value) {
?>
					<li>
						<div class="text">
							<h2 class="title"><span><a href="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LINK'];?>
"><?php echo smarty_modifier_vam_truncate(preg_replace('!<[^>]*?>!', ' ', $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_NAME']),80,"...",true);?>
</a></span></h2>
      				<?php if ($_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_TOTAL'] > 0) {?><div class="description"><span class="rating"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_STAR_RATING'];?>
</span> <span class="reviews"><?php echo @constant('TEXT_TOTAL_REVIEWS');?>
: <?php echo $_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_TOTAL'];?>
</span></div><?php }?>
							<div class="description"><?php echo smarty_modifier_vam_truncate(preg_replace('!<[^>]*?>!', ' ', $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SHORT_DESCRIPTION']),120,"...",true);?>
</div>
							<a href="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LINK'];?>
" class="btn"><?php echo @constant('TEXT_READ_MORE');?>
</a>
						</div>
						<img class="image" src="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_IMAGE_INFO'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_NAME'];?>
" />
					</li>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				</ul>
		</div>
	</div>
</div>

</div>

</div>

<div class="clear"></div><?php }
}
