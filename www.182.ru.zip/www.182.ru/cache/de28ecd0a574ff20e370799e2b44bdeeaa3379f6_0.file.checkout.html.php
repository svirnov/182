<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:54:39
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\checkout.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f47f0b71b2_00631238',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'de28ecd0a574ff20e370799e2b44bdeeaa3379f6' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\checkout.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f47f0b71b2_00631238 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins\\modifier.date_format.php';
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "create_account", 0);
?>

<?php if (@constant('DADATA_API_KEY') != '' && $_SESSION['language'] == "russian") {?>
<!--[if lt IE 10]>
<?php echo '<script'; ?>
 type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ajaxtransport-xdomainrequest/1.0.1/jquery.xdomainrequest.min.js"><?php echo '</script'; ?>
>
<![endif]-->
<?php echo '<script'; ?>
 type="text/javascript" src="https://cdn.jsdelivr.net/jquery.suggestions/16.5.2/js/jquery.suggestions.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript">

$(function () {

var token = "<?php echo @constant('DADATA_API_KEY');?>
";

$("#firstname").suggestions({
  serviceUrl: "https://suggestions.dadata.ru/suggestions/api/4_1/rs",
  partner: "VAMSHOP",
  token: token,
  type: "NAME",
  params: {
    parts: ["NAME"]
  }
});

$("#lastname").suggestions({
  serviceUrl: "https://suggestions.dadata.ru/suggestions/api/4_1/rs",
  partner: "VAMSHOP",
  token: token,
  type: "NAME",
  params: {
    parts: ["SURNAME"]
  }
});

$("#email_address").suggestions({
  serviceUrl: "https://suggestions.dadata.ru/suggestions/api/4_1/rs",
  partner: "VAMSHOP",
  token: token,
  type: "EMAIL",
  params: {
    parts: ["SURNAME"]
  }
});
      
$("#street_address").suggestions({
  serviceUrl: "https://suggestions.dadata.ru/suggestions/api/4_1/rs",
  partner: "VAMSHOP",
  token: token,
  type: "ADDRESS",
  geoLocation: true,
  onSelect: showSelected
});

function join(arr /*, separator */) {
  var separator = arguments.length > 1 ? arguments[1] : " ";
  return arr.filter(function(n){return n}).join(separator);
}

function showSelected(suggestion) {
  var address = suggestion.data;
  $("#postcode").val(address.postal_code);
  if (address.region == "Москва" || address.region == "Санкт-Петербург") {
  $("#state").val(address.region);
  } else {
  $("#state").val(join([
    join([address.region, address.region_type_full], " ")
    //join([address.region, address.region_type], " "),
    //join([address.area_type, address.area], " ")
  ]));
  }
  $("#city").val(join([
    join([address.city_type, address.city], " "),
    join([address.settlement_type, address.settlement], " ")
  ]));
  //$("#street_address").val(
    //join([address.street_type, address.street], " "),
    //join([address.house_type, address.house], " "),
    //join([address.block_type, address.block], " "),
    //join([address.flat_type, address.flat], " ")
  //);
}
  
});
<?php echo '</script'; ?>
>

<?php }
echo '<script'; ?>
 type="text/javascript">

$(function($){

    $('.form-anti-bot, .form-anti-bot-2').hide(); // hide inputs from users
    var answer = $('.form-anti-bot input#anti-bot-a').val(); // get answer
    $('.form-anti-bot input#anti-bot-q').val( answer ); // set answer into other input

    if ( $('form#smart_checkout input#anti-bot-q').length == 0 ) {
        var current_date = new Date();
        var current_year = current_date.getFullYear();
        $('form#smart_checkout').append('<input type="hidden" name="anti-bot-q" id="anti-bot-q" value="'+current_year+'" />'); // add whole input with answer via javascript to form
    }

});

<?php echo '</script'; ?>
>
<div id="load_status"></div>
<div id="box">
<div id="checkout">
<?php echo $_smarty_tpl->tpl_vars['PAYMENT_FIELDS']->value;?>

<?php echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>

<?php if ($_smarty_tpl->tpl_vars['error']->value != '') {?>
<div class="CheckoutError">
<?php echo $_smarty_tpl->tpl_vars['error']->value;?>

</div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['TEXT_ORIGIN_LOGIN']->value) {?>
<p><?php echo $_smarty_tpl->tpl_vars['TEXT_ORIGIN_LOGIN']->value;?>
</p>
<?php }?>

<div id="shipping_box" class="sm_layout_box">
<h2><?php echo $_smarty_tpl->tpl_vars['TITLE_SHIPPING_ADDRESS']->value;?>
</h2>
<?php if ($_smarty_tpl->tpl_vars['ADDRESS_LABEL_SHIPPING_ADDRESS']->value) {
echo $_smarty_tpl->tpl_vars['ADDRESS_LABEL_SHIPPING_ADDRESS']->value;?>

<br />
<?php echo $_smarty_tpl->tpl_vars['BUTTON_SHIPPING_ADDRESS']->value;?>

<?php }
if (!$_SESSION['customer_id']) {?>
<!-- форма -->
<fieldset class="form">
<?php if ($_smarty_tpl->tpl_vars['gender']->value == '1') {?> 
<p><label for="gender"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_gender');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_MALE']->value;?>
&nbsp;<?php echo $_smarty_tpl->tpl_vars['INPUT_FEMALE']->value;?>
</p>
<?php }?>
<p><label for="firstname"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_firstname');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_FIRSTNAME']->value;?>
</p>
<?php if ($_smarty_tpl->tpl_vars['secondname']->value == '1') {?>
<p><label for="secondname"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_secondname');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_SECONDNAME']->value;?>
</p>
<?php }?>
<p><label for="lastname"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_lastname');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_LASTNAME']->value;?>
</p>
<?php if ($_smarty_tpl->tpl_vars['birthdate']->value == '1') {?> 
<p><label for="dob"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_birthdate');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_DOB']->value;?>
</p>
<?php }?>
</fieldset>
<?php if ($_smarty_tpl->tpl_vars['company']->value == '1') {?>
<fieldset class="form">
<p><label for="company"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_company');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_COMPANY']->value;?>
</p>
</fieldset>
<?php }?>
<div id="shipping_address">
<fieldset class="form">
<?php if ($_smarty_tpl->tpl_vars['street_address']->value == '1') {
}
if ($_smarty_tpl->tpl_vars['street_address']->value == '1') {?>
<p><label for="address"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_street');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_STREET']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['suburb']->value == '1') {?>
<p><label for="suburb"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_suburb');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_SUBURB']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['postcode']->value == '1') {?>
<p><label for="postcode"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_code');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_CODE']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['city']->value == '1') {?>
<p><label for="city"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_city');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_CITY']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['country']->value == '1') {?>
<div id="shipping_country_box">
<div id="shipping_country">
<p><label for="country"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_country');?>
</label> <?php echo $_smarty_tpl->tpl_vars['SELECT_COUNTRY']->value;?>
</p>
</div><!--div end shipping_country -->
</div><!--div end shipping_country_box -->
<?php }
if ($_smarty_tpl->tpl_vars['state']->value == '1') {?>
<div id="shipping_state_box">
<div id="shipping_state">
<p><label for="state"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_state');?>
</label> <span id="stateXML"><?php echo $_smarty_tpl->tpl_vars['INPUT_STATE']->value;?>
</span></p>
</div><!--div end shipping_state -->
</div><!--div end shipping_state_box -->
<?php }?>
</fieldset>
</div> <!--div end shipping_address -->
<?php }?>
</div> <!--div end shipping_box --> 


<?php if ($_smarty_tpl->tpl_vars['sc_payment_address_show']->value) {?>
<div id="payment_address_box"  class="sm_layout_box">
<h2><?php echo $_smarty_tpl->tpl_vars['TITLE_PAYMENT_ADDRESS']->value;?>
</h2>
<?php if ($_smarty_tpl->tpl_vars['ADDRESS_LABEL_PAYMENT_ADDRESS']->value) {
echo $_smarty_tpl->tpl_vars['ADDRESS_LABEL_PAYMENT_ADDRESS']->value;?>

<br />
<?php echo $_smarty_tpl->tpl_vars['BUTTON_PAYMENT_ADDRESS']->value;?>

<?php }
if (!$_SESSION['customer_id']) {?>
<div id="payment_address_checkbox">
<?php echo $_smarty_tpl->tpl_vars['PAYMENT_ADDRESS_CHECKBOX']->value;
echo $_smarty_tpl->tpl_vars['TEXT_SHIPPING_SAME_AS_PAYMENT']->value;?>

</div>
<div id="payment_address">
<!-- форма -->
<fieldset class="form">
<?php if ($_smarty_tpl->tpl_vars['gender_payment']->value == '1') {?> 
<p><label for="gender_payment"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_gender');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_MALE_PAYMENT']->value;?>
&nbsp;<?php echo $_smarty_tpl->tpl_vars['INPUT_FEMALE_PAYMENT']->value;?>
</p>
<?php }?>
<p><label for="firstname_payment"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_firstname');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_FIRSTNAME_PAYMENT']->value;?>
</p>
<?php if ($_smarty_tpl->tpl_vars['secondname_payment']->value == '1') {?>
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_secondname');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_SECONDNAME_PAYMENT']->value;?>
</p>
<?php }?>
<p><label for="lastname_payment"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_lastname');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_LASTNAME_PAYMENT']->value;?>
</p>
<?php if ($_smarty_tpl->tpl_vars['birthdate_payment']->value == '1') {?> 
<p><label for="dob"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_birthdate');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_DOB_PAYMENT']->value;?>
</p>
<?php }?>
</fieldset>
<?php if ($_smarty_tpl->tpl_vars['company_payment']->value == '1') {?>
<fieldset class="form">
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_company');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_COMPANY_PAYMENT']->value;?>
</p>
</fieldset>
<?php }?>
<fieldset class="form">
<?php if ($_smarty_tpl->tpl_vars['street_address_payment']->value == '1') {
}
if ($_smarty_tpl->tpl_vars['street_address_payment']->value == '1') {?>
<p><label for="address"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_street');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_STREET_PAYMENT']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['suburb_payment']->value == '1') {?>
<p><label for="suburb"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_suburb');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_SUBURB_PAYMENT']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['postcode_payment']->value == '1') {?>
<p><label for="postcode"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_code');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_CODE_PAYMENT']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['city_payment']->value == '1') {?>
<p><label for="city"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_city');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_CITY_PAYMENT']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['country_payment']->value == '1') {?>
<div id="payment_country_box">
<div id="payment_country_">
<p><label for="country"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_country');?>
</label> <?php echo $_smarty_tpl->tpl_vars['SELECT_COUNTRY_PAYMENT']->value;?>
</p>
</div><!--div end payment_country -->
</div><!--div end payment_country_box -->
<?php }
if ($_smarty_tpl->tpl_vars['state_payment']->value == '1') {?>
<div id="shipping_state_box">
<div id="shipping_state">
<p><label for="state"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_state');?>
</label> <span id="stateXMLPayment"><?php echo $_smarty_tpl->tpl_vars['INPUT_STATE_PAYMENT']->value;?>
</span></p>
</div><!--div end shipping_state -->
</div><!--div end shipping_state_box -->
<?php }?>
</fieldset>
</div><!--div end payment_address -->
<?php }?>
</div><!--div end payment_address_box -->
<?php }?>

<?php if (!$_SESSION['customer_id']) {?>
<div id="contact_box" class="sm_layout_box">
<fieldset class="form">
<h2><?php echo $_smarty_tpl->tpl_vars['TITLE_CONTACT_ADDRESS']->value;?>
</h2>
<p><label for="email"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_email');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_EMAIL']->value;?>
</p>
<?php if ($_smarty_tpl->tpl_vars['telephone']->value == '1') {?>
<p><label for="telephone"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_tel');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_TEL']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['fax']->value == '1') {?>
<p><label for="fax"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_fax');?>
</label> <?php echo $_smarty_tpl->tpl_vars['INPUT_FAX']->value;?>
</p>
<?php }
if ($_smarty_tpl->tpl_vars['INPUT_CUSTOMERS_EXTRA_FIELDS']->value) {
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['INPUT_CUSTOMERS_EXTRA_FIELDS']->value, 'customers_extra_filelds');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['customers_extra_filelds']->value) {
?>
<p><label><?php echo $_smarty_tpl->tpl_vars['customers_extra_filelds']->value['NAME'];?>
:</label> <?php echo $_smarty_tpl->tpl_vars['customers_extra_filelds']->value['VALUE'];?>
</p>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<?php }?>
</fieldset>
</div> <!--div end contact_box -->   
<?php }?>

<?php if (!$_SESSION['customer_id']) {?>
<div id="password_box" class="sm_layout_box">
<?php if ($_smarty_tpl->tpl_vars['TITLE_CONTACT_PASSWORD']->value) {?><h2><?php echo $_smarty_tpl->tpl_vars['TITLE_CONTACT_PASSWORD']->value;?>
</h2><?php }?>
<div id="password_checkbox">
<?php echo $_smarty_tpl->tpl_vars['PASSWORD_CHECKBOX']->value;?>

</div>
<?php if ($_smarty_tpl->tpl_vars['create_password']->value == '1') {?>
<div id="password_fields">
<p><?php echo $_smarty_tpl->tpl_vars['TEXT_CONTACT_PASSWORD']->value;?>
</p>
</div> <!--div end password_fields --> 
<?php }?>
</div> <!--div end password_box -->  
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['shipping']->value == 'true') {?>
<div id="shipping_modules_box" class="sm_layout_box">
<h2><?php echo $_smarty_tpl->tpl_vars['TITLE_SHIPPING_MODULES']->value;?>
</h2>
<div id="shipping_options"> 
<?php echo $_smarty_tpl->tpl_vars['SHIPPING_BLOCK']->value;?>

</div> <!--div end shipping_options-->
</div> <!--div end shipping_modules_box --> 
<?php }?>

<div id="payment_options" class="sm_layout_box"> 
<h2><?php echo $_smarty_tpl->tpl_vars['TITLE_PAYMENT_MODULES']->value;?>
</h2>
<?php echo $_smarty_tpl->tpl_vars['PAYMENT_BLOCK']->value;?>

</div> <!--div end payment_options-->

<?php if ($_smarty_tpl->tpl_vars['comments']->value == '1') {?>
<div id="comment_box" class="sm_layout_box">
<h2><?php echo $_smarty_tpl->tpl_vars['TITLE_COMMENTS']->value;?>
</h2>
<?php echo $_smarty_tpl->tpl_vars['COMMENTS']->value;?>

</div><!--div end comment_box--> 
<?php }?>

<div id="order_total_modules" class="sm_layout_box">
<h2><?php echo $_smarty_tpl->tpl_vars['TITLE_TOTALS']->value;?>
</h2>
<div class="contentText">
<div style="float: right;">
<table border="0" cellspacing="0" cellpadding="2">
<?php echo $_smarty_tpl->tpl_vars['ORDER_TOTALS']->value;?>

</table>
</div>
</div>
<p>&nbsp;</p>
</div><!--div end order_total_modules -->

<?php if ($_smarty_tpl->tpl_vars['conditions']->value == 'true') {?>
<div id="conditions" class="sm_layout_box">
<?php echo $_smarty_tpl->tpl_vars['AGB_checkbox']->value;?>
 <?php echo @constant('SC_CONDITION');?>
 <?php echo $_smarty_tpl->tpl_vars['AGB_LINK']->value;?>
 <?php echo @constant('SC_CONDITION_END');?>

</div><!--div end conditions --> 
<?php }?>

<div class="form-anti-bot" style="clear:both;">
	<strong>Current <span style="display:none;">month</span> <span style="display:inline;">ye@r</span> <span style="display:none;">day</span></strong> <span class="required">*</span>
	<input type="hidden" name="anti-bot-a" id="anti-bot-a" value="<?php echo smarty_modifier_date_format(time(),"%Y");?>
" />
	<input type="text" name="anti-bot-q" id="anti-bot-q" size="30" value="19" />
</div>
<div class="form-anti-bot-2" style="display:none;">
	<strong>Leave this field empty</strong> <span class="required">*</span>
	<input type="text" name="anti-bot-e-email-url" id="anti-bot-e-email-url" size="30" value=""/>
</div>

<br />
<div class="pagecontentfooter">
<?php echo $_smarty_tpl->tpl_vars['BUTTON_CONTINUE']->value;?>

</div>
<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;?>

</div><!-- Div end checkout -->
</div><!-- Div end checkout_container -->
<?php }
}
