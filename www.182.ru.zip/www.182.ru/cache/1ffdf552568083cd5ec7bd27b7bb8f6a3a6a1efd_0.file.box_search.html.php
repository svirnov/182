<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:26
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_search.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fae4e1c2_86763225',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1ffdf552568083cd5ec7bd27b7bb8f6a3a6a1efd' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_search.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fae4e1c2_86763225 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<div class="search">
	<?php echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>

		<input class="span4" id="quick_find_keyword" name="keywords" type="text" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_search');?>
" />
		<input class="btn search-bt" type="submit" value="" />
	<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;?>

	<div class="ajaxQuickFind" id="ajaxQuickFind" style="text-align: left; position: absolute; z-index: 999; background-color: #fff;"></div>
</div>
<br />	
<?php echo '<script'; ?>
 type="text/javascript">
// <![CDATA[

$(document).ready(function(){

  $("#quick_find_keyword").keyup(function(){
      var searchString = $("#quick_find_keyword").val(); 
      $.ajax({
      	url: "index_ajax.php",             
      	dataType : "html",
      	type: "POST",
      	data: "q=includes/modules/ajax/ajaxQuickFind.php&keywords="+searchString,
      	success: function(msg){$("#ajaxQuickFind").html(msg);}            
 });     
                           
                           
   });


})


// ]]>
<?php echo '</script'; ?>
>
<?php }
}
