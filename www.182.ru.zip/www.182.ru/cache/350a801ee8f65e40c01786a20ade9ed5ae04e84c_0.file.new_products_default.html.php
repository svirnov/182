<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:27
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\new_products_default.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fb4c4b47_41556009',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '350a801ee8f65e40c01786a20ade9ed5ae04e84c' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\new_products_default.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fb4c4b47_41556009 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_vam_truncate')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins_vam\\modifier.vam_truncate.php';
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "new_products", 0);
?>
 
<h1><a href="<?php echo $_smarty_tpl->tpl_vars['NEW_PRODUCTS_LINK']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_text');?>
</a></h1>
<div class="page">
<div class="pageItem">

<!-- start: products listing -->
<div class="row-fluid shop-products">
	<ul class="thumbnails">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_content']->value, 'module_data', false, NULL, 'aussen', array (
  'index' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['module_data']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_aussen']->value['index']++;
?>
		<li class="item span4<?php if ((isset($_smarty_tpl->tpl_vars['__smarty_foreach_aussen']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_aussen']->value['index'] : null)%3 == 0) {?> first<?php }?>">
			<div class="thumbnail text-center">
				<?php if ($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SPECIAL'] > 0) {?><div class="description"><span class="discount">-<?php echo round($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SPECIAL']);?>
%</span></div><?php }?>
				<a href="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LINK'];?>
" class="image"><img src="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_IMAGE'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_NAME'];?>
" /><span class="frame-overlay"></span><span class="price"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_PRICE'];?>
</span><?php if ($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LABEL']) {
echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LABEL'];
}?></a>
			<div class="inner notop nobottom text-left">
				<h4 class="title"><a href="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_NAME'];?>
</a></h4>
				<?php if ($_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_TOTAL'] > 0) {?><div class="description"><span class="rating"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_STAR_RATING'];?>
</span> <span class="reviews"><?php echo @constant('TEXT_TOTAL_REVIEWS');?>
: <?php echo $_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_TOTAL'];?>
</span></div><?php }?>
				<div class="description"><?php echo smarty_modifier_vam_truncate(preg_replace('!<[^>]*?>!', ' ', $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SHORT_DESCRIPTION']),30,"...",true);?>
</div>
			</div>
			</div>
			<div class="inner darken notop">
				<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_BUTTON_BUY_NOW_NEW'];?>

			</div>
		</li>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

	</ul>
</div>  
<!-- end: products listing -->  
  
<div class="clear"></div>
</div>

</div><?php }
}
