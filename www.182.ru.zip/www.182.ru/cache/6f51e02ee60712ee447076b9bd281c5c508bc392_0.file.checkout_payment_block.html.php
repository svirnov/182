<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:54:38
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\checkout_payment_block.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f47e81b329_91089808',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6f51e02ee60712ee447076b9bd281c5c508bc392' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\checkout_payment_block.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f47e81b329_91089808 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_cycle')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins\\function.cycle.php';
echo '<script'; ?>
 type="text/javascript">

$(document).ready(function() {

	$("div#qiwi_rest").hide();
	$("div#schet").hide();
	$("div#kvitancia").hide();

	$("input#qiwi_rest").click(function (){
		$("div#qiwi_rest").toggle();
	});
	$("input#schet").click(function (){
		$("div#schet").toggle();
	});
	$("input#kvitancia").click(function (){
		$("div#kvitancia").toggle();
	});

});

$(document).ajaxStop(function() {

if ($("input#qiwi_rest").is(":checked")) {
  $("div#qiwi_rest").show();
} else {
  $("div#qiwi_rest").hide();
}

if ($("input#schet").is(":checked")) {
  $("div#schet").show();
} else {
  $("div#schet").hide();
}

if ($("input#kvitancia").is(":checked")) {
  $("div#kvitancia").show();
} else {
  $("div#kvitancia").hide();
}

});

<?php echo '</script'; ?>
>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_content']->value, 'module_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['module_data']->value) {
?> 
<div class="<?php echo smarty_function_cycle(array('values'=>"itemOdd,itemEven"),$_smarty_tpl);?>
">
<p>
<label for="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['selection'];?>
 <?php echo $_smarty_tpl->tpl_vars['module_data']->value['icon'];?>
 <span class="bold"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['module'];?>
</span> <span class="bold"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['module_cost'];?>
</span></label>
</p>

<?php if ($_smarty_tpl->tpl_vars['module_data']->value['description']) {?>
<p>
<?php echo $_smarty_tpl->tpl_vars['module_data']->value['description'];?>

</p>
<?php }
if ($_smarty_tpl->tpl_vars['module_data']->value['error']) {?> 
<p>
<?php echo $_smarty_tpl->tpl_vars['module_data']->value['error'];?>

</p>
<?php } else { ?> 
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_data']->value['fields'], 'method_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['method_data']->value) {
?> 
<p>
<?php echo $_smarty_tpl->tpl_vars['method_data']->value['title'];?>
&nbsp;<?php echo $_smarty_tpl->tpl_vars['method_data']->value['field'];?>

</p> 
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<?php }?>
</div>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
}
}
