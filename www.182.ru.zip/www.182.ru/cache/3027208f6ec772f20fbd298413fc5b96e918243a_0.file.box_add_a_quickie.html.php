<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:26
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_add_a_quickie.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fad59f81_59521456',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3027208f6ec772f20fbd298413fc5b96e918243a' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_add_a_quickie.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fad59f81_59521456 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<section class="widget inner">
	<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_add_a_quickie');?>
</h3>
		<?php echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>

			<div class="control-group">
			<label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_quickie');?>
</label>
				<div class="controls">
					<?php echo $_smarty_tpl->tpl_vars['INPUT_FIELD']->value;?>

				</div>
			</div>
			<div class="control-group">
				<div class="controls">
					<button type="submit" class="btn btn-inverse"><i class="fa fa-check"></i> <?php echo @constant('BOX_HEADING_ADD_PRODUCT_ID');?>
</button>
				</div>
			</div>			
			<div class="ajaxAddQuickie" id="ajaxAddQuickie" style="text-align: left;"></div>
		<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;?>

</section>
<?php echo '<script'; ?>
 type="text/javascript">
// <![CDATA[

$(document).ready(function(){

  $("#quick_add_quickie").keyup(function(){
      var searchString = $("#quick_add_quickie").val(); 
      $.ajax({
      	url: "index_ajax.php",             
      	dataType : "html",
      	type: "POST",
      	data: "q=includes/modules/ajax/ajaxAddQuickie.php&quickie="+searchString,
      	success: function(msg){$("#ajaxAddQuickie").html(msg);}            
 });     
                           
                           
   });


})


// ]]>
<?php echo '</script'; ?>
><?php }
}
