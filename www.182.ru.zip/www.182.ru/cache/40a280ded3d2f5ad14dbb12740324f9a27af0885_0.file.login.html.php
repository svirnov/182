<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:56:39
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\login.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f4f7225517_73667836',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '40a280ded3d2f5ad14dbb12740324f9a27af0885' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\login.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f4f7225517_73667836 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "login", 0);
?>

<?php echo '<script'; ?>
 type="text/javascript" src="jscript/modified.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript">

$(document).ready(function(){

$(function () {
    $('#login :input:text:visible:enabled:first').focus();
})

})

<?php echo '</script'; ?>
>
<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_login');?>
</h1>
<?php echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>

<?php if ($_smarty_tpl->tpl_vars['info_message']->value != '') {?>
<div class="contacterror"><?php echo $_smarty_tpl->tpl_vars['info_message']->value;?>
</div>
<?php }?>
<div class="page">
<div class="pagecontent">
<dl class="Login">
<dt class="Login">
</dt>

<dd class="Login">
<span class="bold"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_new');?>
</span>
</dd>

<dd>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_new');?>

</dd>

<dd>
<?php echo $_smarty_tpl->tpl_vars['BUTTON_NEW_ACCOUNT']->value;?>

</dd>

</dl>
<dl class="Login">
<dt class="Login">
</dt>

<dd>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_returning');?>

</dd>

<?php echo '<script'; ?>
 type="text/javascript">

src="captcha.php";
function reload(){
        document.captcha.src='loading.gif';
        document.captcha.src=src+'?rand='+Math.random();
}

<?php echo '</script'; ?>
>

<dd>
<!-- форма -->
<fieldset class="form">
<legend><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_returning');?>
</legend>
<?php if ($_smarty_tpl->tpl_vars['CAPTCHA_IMG']->value != '') {?><p><?php echo $_smarty_tpl->tpl_vars['CAPTCHA_IMG']->value;?>
 <a href="javascript:void(0)" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_update');?>
" onclick="reload()"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_update');?>
</a> <?php echo $_smarty_tpl->tpl_vars['CAPTCHA_INPUT']->value;?>
</p><?php }?>
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_email');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_MAIL']->value;?>
</p>
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_password');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_PASSWORD']->value;?>
</p>
</fieldset>
<!-- /форма -->

<p>
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_LOST_PASSWORD']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_lost_password');?>
</a>
</p>

<p>
<?php echo $_smarty_tpl->tpl_vars['BUTTON_LOGIN']->value;?>

</p>

</dd>

</dl>
<div class="clear"></div>
</div>
</div>
<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;
}
}
