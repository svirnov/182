<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:27
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_cart_pull.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fb1e8483_36307099',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '14b8b3f1716a447df952f71db825ea4f39c63f8c' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_cart_pull.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fb1e8483_36307099 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_counter')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins\\function.counter.php';
if (!is_callable('smarty_modifier_vam_truncate')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins_vam\\modifier.vam_truncate.php';
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "index", 0);
?>

<?php if ($_smarty_tpl->tpl_vars['deny_cart']->value != 'true') {
if ($_smarty_tpl->tpl_vars['empty']->value == 'false') {?>
<div class="widget inner shopping-cart-widget dropdown">
	<div class="cart-dropdown">
			<div class="content">
				<div class="products">
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products']->value, 'products_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['products_data']->value) {
?>
						<div class="media">
							<a class="pull-right" href="<?php echo $_smarty_tpl->tpl_vars['products_data']->value['LINK'];?>
">
								<img class="media-object" src="<?php echo $_smarty_tpl->tpl_vars['products_data']->value['IMAGE'];?>
" alt="" title="" width="40" height="40" />
							</a>
						<div class="media-body">
						<?php if (@constant('AJAX_CART') == 'true') {?>
		<form id="update_cart<?php echo smarty_function_counter(array('name'=>1),$_smarty_tpl);?>
" class="cart_quantity" action="<?php echo $_smarty_tpl->tpl_vars['products_data']->value['LINK'];?>
/action/update_product" method="post" onsubmit="doDelProduct(<?php echo smarty_function_counter(array('name'=>2),$_smarty_tpl);?>
); return false;"><?php echo $_smarty_tpl->tpl_vars['products_data']->value['PRODUCTS_QTY'];?>

		<?php }?>
		                  <h4 class="media-heading"><a href="<?php echo $_smarty_tpl->tpl_vars['products_data']->value['LINK'];?>
"><?php echo smarty_modifier_vam_truncate($_smarty_tpl->tpl_vars['products_data']->value['NAME'],@constant('MAX_DISPLAY_CART'),"...",true);?>
</a> <?php if (@constant('AJAX_CART') == 'true') {?><input type="image" src="images/delete.gif" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_delete');?>
" /></form><?php }?></h4>
								<?php if ($_smarty_tpl->tpl_vars['products_data']->value['ATTRIBUTES'] != '') {?> 
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products_data']->value['ATTRIBUTES'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?> 
								<?php echo $_smarty_tpl->tpl_vars['item_data']->value['NAME'];?>
: <?php echo $_smarty_tpl->tpl_vars['item_data']->value['VALUE'];?>
<br />
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 
								<?php }?>
							<?php echo $_smarty_tpl->tpl_vars['products_data']->value['QTY'];?>
 x <?php echo $_smarty_tpl->tpl_vars['products_data']->value['PRICE'];?>

						</div>
						</div>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				</div>
				<?php if ($_smarty_tpl->tpl_vars['DISCOUNT']->value) {?>
				<p class="subtotal">
					<strong><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_discount');?>
</strong>
					<span class="amount"><?php echo $_smarty_tpl->tpl_vars['DISCOUNT']->value;?>
</span>
				</p>
				<?php }?>
				<p class="subtotal">
					<strong><?php echo $_smarty_tpl->tpl_vars['UST']->value;
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_total');?>
</strong>
					<span class="amount"><?php echo $_smarty_tpl->tpl_vars['TOTAL']->value;?>
</span>
				</p>
				<p class="buttons">
					<a class="btn btn-inverse viewcart" href="javascript: history.go(-1)"><i class="fa fa-arrow-left"></i> <?php echo @constant('TEXT_BACK');?>
</a>
					<a class="btn btn-inverse viewcart" href="<?php echo $_smarty_tpl->tpl_vars['LINK_CART']->value;?>
"><i class="fa fa-shopping-cart"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'link_cart');?>
</a>
					<a class="btn btn-inverse checkout" href="<?php echo $_smarty_tpl->tpl_vars['LINK_CHECKOUT']->value;?>
"><i class="fa fa-check"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_checkout');?>
 &rarr;</a>
				</p>
			</div>
	</div>
</div>
<?php } else { ?>
<div class="widget inner shopping-cart-widget">
	<div class="cart-dropdown">
			<div class="content">
           <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_empty_cart');?>
 
			</div>
	</div>
</div>
<?php }
}?>

<?php }
}
