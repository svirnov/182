<?php
/* Smarty version 3.1.30, created on 2016-09-05 11:46:41
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\ask_a_question.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd30f1aba958_88349694',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f30b06938ca444215fd8d318db3e00781d3986a0' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\ask_a_question.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd30f1aba958_88349694 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins\\modifier.date_format.php';
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "ask_a_question", 0);
?>

<?php echo '<script'; ?>
 type="text/javascript">

$(function($){

    $('.form-anti-bot, .form-anti-bot-2').hide(); // hide inputs from users
    var answer = $('.form-anti-bot input#anti-bot-a').val(); // get answer
    $('.form-anti-bot input#anti-bot-q').val( answer ); // set answer into other input

    if ( $('form#ask_a_question input#anti-bot-q').length == 0 ) {
        var current_date = new Date();
        var current_year = current_date.getFullYear();
        $('form#ask_a_question').append('<input type="hidden" name="anti-bot-q" id="anti-bot-q" value="'+current_year+'" />'); // add whole input with answer via javascript to form
    }

});

<?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>


<div id="content">

<?php if ($_smarty_tpl->tpl_vars['error']->value != '') {?>
<div class="contacterror">
<?php echo $_smarty_tpl->tpl_vars['error']->value;?>

</div>
<?php }?>
<div class="page">
<div class="pagecontent">
<!-- форма -->
<fieldset class="form">
<legend><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_question');?>
 <?php echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;?>
</legend>
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_firstname');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_FIRSTNAME']->value;?>
</p>
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_lastname');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_LASTNAME']->value;?>
</p>
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_email');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_EMAIL']->value;?>
</p>
<p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_message');?>
 <?php echo $_smarty_tpl->tpl_vars['INPUT_TEXT']->value;?>
</p>
</fieldset>
<div class="form-anti-bot" style="clear:both;">
	<strong>Current <span style="display:none;">month</span> <span style="display:inline;">ye@r</span> <span style="display:none;">day</span></strong> <span class="required">*</span>
	<input type="hidden" name="anti-bot-a" id="anti-bot-a" value="<?php echo smarty_modifier_date_format(time(),"%Y");?>
" />
	<input type="text" name="anti-bot-q" id="anti-bot-q" size="30" value="19" />
</div>
<div class="form-anti-bot-2" style="display:none;">
	<strong>Leave this field empty</strong> <span class="required">*</span>
	<input type="text" name="anti-bot-e-email-url" id="anti-bot-e-email-url" size="30" value=""/>
</div>
<!-- /форма -->
</div>
</div>

<div class="pagecontentfooter">
<?php echo $_smarty_tpl->tpl_vars['BUTTON_SUBMIT']->value;?>

</div>
<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;?>


</div><?php }
}
