<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:27
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\main_content.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fb5b8d85_77032369',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '137e19e5481e1933214fabf9f08f0e7b25474cb5' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\main_content.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fb5b8d85_77032369 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "index", 0);
?>

<?php echo $_smarty_tpl->tpl_vars['MODULE_error']->value;?>

<p>
<?php echo $_smarty_tpl->tpl_vars['text']->value;?>

</p>
<?php echo $_smarty_tpl->tpl_vars['MODULE_featured_products']->value;?>

<?php echo $_smarty_tpl->tpl_vars['MODULE_new_products']->value;?>

<?php echo $_smarty_tpl->tpl_vars['MODULE_latest_news']->value;?>

<?php echo $_smarty_tpl->tpl_vars['MODULE_upcoming_products']->value;
}
}
