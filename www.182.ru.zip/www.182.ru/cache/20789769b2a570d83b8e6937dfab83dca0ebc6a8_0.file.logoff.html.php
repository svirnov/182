<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:54:42
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\logoff.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f482501bd6_54495801',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '20789769b2a570d83b8e6937dfab83dca0ebc6a8' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\logoff.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f482501bd6_54495801 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "logoff", 0);
?>
 
<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_logoff');?>
</h1>
<div class="page">
<div class="pagecontent">
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_logoff');?>

</p>
</div>
<div class="pagecontentfooter">
<?php echo $_smarty_tpl->tpl_vars['BUTTON_CONTINUE']->value;?>

</div>
</div><?php }
}
