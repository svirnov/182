<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:08:18
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\product_info\product_info_v1.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd0bd203d094_06879852',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c9e27e68ee18589f60c1576c3e4ddfe5d81655a3' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\product_info\\product_info_v1.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd0bd203d094_06879852 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "product_info", 0);
?>


<?php if ($_smarty_tpl->tpl_vars['info_message']->value) {?>
<div class="contacterror">
<?php echo $_smarty_tpl->tpl_vars['info_message']->value;?>

</div>
<?php }?>

<div itemscope itemtype="http://schema.org/Product">

<?php echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>


		<h2 itemprop="name"><?php echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;?>
</h2>              

		<div class="row-fluid">
			<!-- start: Product image -->
			<div class="span6 product-images">
				<div class="thumbnail big text-center">
					<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_SPECIAL']->value > 0) {?><div class="description"><span class="discount">-<?php echo round($_smarty_tpl->tpl_vars['PRODUCTS_SPECIAL']->value);?>
%</span></div><?php }?>
					<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_POPUP_LINK']->value != '') {?><a href="<?php echo $_smarty_tpl->tpl_vars['PRODUCTS_POPUP_IMAGE']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;?>
" class="lightbox"><?php }?><img itemprop="image" id="img" src="<?php echo $_smarty_tpl->tpl_vars['PRODUCTS_IMAGE']->value;?>
" alt="<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_IMAGE_DESCRIPTION']->value != '') {
echo $_smarty_tpl->tpl_vars['PRODUCTS_IMAGE_DESCRIPTION']->value;
} else {
echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;
}?>" />
					<span class="frame-overlay"></span>
					<?php if ($_smarty_tpl->tpl_vars['LABEL_ID']->value > 0) {
echo $_smarty_tpl->tpl_vars['PRODUCT_LABEL']->value;
}?>
					<span class="zoom"><i class="fa fa-search-plus"></i></span>
					<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_POPUP_LINK']->value != '') {?></a><?php }?>
				</div>
				<div class="row-fluid small">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['mo_img']->value, 'img_values', false, NULL, 'mo_pic', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['img_values']->value) {
?>
					<div class="span4 thumbnail text-center">
						<?php if ($_smarty_tpl->tpl_vars['img_values']->value['PRODUCTS_MO_POPUP_LINK'] != '') {?><a href="<?php echo $_smarty_tpl->tpl_vars['img_values']->value['PRODUCTS_MO_POPUP_IMAGE'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;?>
" class="lightbox"><?php }?><img src="<?php echo $_smarty_tpl->tpl_vars['img_values']->value['PRODUCTS_MO_IMAGE'];?>
" itemprop="image" alt="<?php if ($_smarty_tpl->tpl_vars['img_values']->value['PRODUCTS_MO_IMAGE_DESCRIPTION'] != '') {
echo $_smarty_tpl->tpl_vars['img_values']->value['PRODUCTS_MO_IMAGE_DESCRIPTION'];
} else {
echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;
}?>" />
						<span class="frame-overlay"></span>
						<span class="zoom"><i class="fa fa-search-plus"></i></span>
						<?php if ($_smarty_tpl->tpl_vars['img_values']->value['PRODUCTS_MO_POPUP_LINK'] != '') {?></a><?php }?>
					</div>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				</div>
			</div>
			<!-- end: Product image -->
			<!-- start: Product title -->
				<div class="span6 product-info">

					<div class="description inner" itemprop="offers" itemscope itemtype="http://schema.org/Offer"><span class="price"><?php echo $_smarty_tpl->tpl_vars['PRODUCTS_PRICE']->value;?>
</span><meta itemprop="price" content="<?php echo $_smarty_tpl->tpl_vars['PRODUCTS_PRICE_PLAIN']->value;?>
"><meta itemprop="priceCurrency" content="<?php echo $_SESSION['currency'];?>
"></div>

          <?php if ($_smarty_tpl->tpl_vars['REVIEWS_TOTAL']->value) {?>
					<div class="inner">
          <?php if ($_smarty_tpl->tpl_vars['REVIEWS_TOTAL']->value) {
echo @constant('TEXT_TOTAL_REVIEWS');?>
: <?php echo $_smarty_tpl->tpl_vars['REVIEWS_TOTAL']->value;?>
, <?php }?>
          <?php if ($_smarty_tpl->tpl_vars['REVIEWS_RATING']->value) {
echo @constant('TEXT_REVIEWS_RATING');?>
: <?php echo $_smarty_tpl->tpl_vars['STAR_RATING']->value;
}?>
					</div>
					<?php }?>

					<div class="inner nobottom product-cart">
								<label><?php echo @constant('TEXT_PRODUCT_QTY');?>
</label>
								<?php echo $_smarty_tpl->tpl_vars['ADD_QTY']->value;?>

								<button id="add_to_cart" type="submit" class="btn btn-inverse"><i class="fa fa-shopping-cart"></i> <?php echo @constant('IMAGE_BUTTON_IN_CART');?>
</button>
								<?php if ($_smarty_tpl->tpl_vars['KUPI_V_KREDIT_BUTTON']->value) {?>
								<?php echo $_smarty_tpl->tpl_vars['KUPI_V_KREDIT_BUTTON']->value;?>

								<?php }?>
					</div>

					<?php if ($_smarty_tpl->tpl_vars['MODULE_product_options']->value != '') {?>
					<div class="inner">
						<?php echo $_smarty_tpl->tpl_vars['MODULE_product_options']->value;?>

					</div>
					<?php }?>

					<?php if ($_smarty_tpl->tpl_vars['MODULE_graduated_price']->value != '') {?>
					<div class="inner">
						<?php echo $_smarty_tpl->tpl_vars['MODULE_graduated_price']->value;?>

					</div>
					<?php }?>

					<div class="inner">
						<a class="iframe" target="_blank" href="<?php echo $_smarty_tpl->tpl_vars['ASK_PRODUCT_QUESTION_LINK']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'question');?>
</a>&nbsp;<?php echo $_smarty_tpl->tpl_vars['ASK_PRODUCT_QUESTION']->value;?>

					</div>

					<?php if ($_smarty_tpl->tpl_vars['SHIPPING_NAME']->value) {?>
					<div class="inner">
						<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_shippingtime');?>
&nbsp;<?php if ($_smarty_tpl->tpl_vars['SHIPPING_IMAGE']->value) {?><img src="<?php echo $_smarty_tpl->tpl_vars['SHIPPING_IMAGE']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['SHIPPING_NAME']->value;?>
" /><?php }?>&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['SHIPPING_NAME']->value;?>

					</div>
					<?php }?>
					
				</div>
			<!-- end: Product title -->
		</div>

<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;?>


		<div class="row-fluid">

			<div class="row-fluid product-tabs">
				<div class="widget">

					<ul class="nav nav-tabs">
						<li class="active"><a href="#description" data-toggle="tab"><i class="fa fa-thumbs-up"></i> <?php echo @constant('TEXT_PRODUCT_DESCRIPTION');?>
</a></li>
						<li><a href="#reviews" data-toggle="tab"><i class="fa fa-comment"></i> <?php echo @constant('TEXT_PRODUCT_REVIEWS');?>
</a></li>
					</ul>

					<div class="tab-content">

						<div class="tab-pane inner fade in notop active" id="description">
							<div itemprop="description"><?php echo $_smarty_tpl->tpl_vars['PRODUCTS_DESCRIPTION']->value;?>
</div>

						<?php if ($_smarty_tpl->tpl_vars['specifications']->value) {?>
						<div class="inner">
							<!-- Specifications -->
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['specifications_data']->value, 'spec_group', false, NULL, 'outer', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['spec_group']->value) {
?>
							<strong><?php echo $_smarty_tpl->tpl_vars['spec_group']->value['GROUP_NAME'];?>
:</strong><br />
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['spec_group']->value['DATA'], 'spec', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['spec']->value) {
?>
							<?php echo $_smarty_tpl->tpl_vars['spec']->value['NAME'];?>
: <?php echo $_smarty_tpl->tpl_vars['spec']->value['VALUE'];?>
<br /> 
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							<!-- /Specifications -->
						</div>
						<?php }?>
	
						<?php if ($_smarty_tpl->tpl_vars['extra_fields_data']->value) {?>
						<div class="inner">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['extra_fields_data']->value, 'extra_fields', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['extra_fields']->value) {
?> 
							<?php echo $_smarty_tpl->tpl_vars['extra_fields']->value['NAME'];?>
: <?php echo $_smarty_tpl->tpl_vars['extra_fields']->value['VALUE'];?>
<br /> 
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

						</div>
						<?php }?>					
	
						<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_TAGS']->value) {?>
						<div class="inner">
							<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_tags');?>
: 
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tags_data']->value, 'tag', false, NULL, 'tags', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['tag']->value) {
?>
							<a href="<?php echo $_smarty_tpl->tpl_vars['tag']->value['LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['NAME'];?>
</a> 
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

						</div>
						<?php }?>
							
						<?php if ($_smarty_tpl->tpl_vars['MODULE_tpt']->value != '') {?>
						<div class="inner">
							<?php echo $_smarty_tpl->tpl_vars['MODULE_tpt']->value;?>

						</div>
						<?php }?>
							
						<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_URL']->value != '') {?>
						<div class="inner">
							<?php echo $_smarty_tpl->tpl_vars['PRODUCTS_URL']->value;?>

						</div>
						<?php }?>

						</div>

						<div class="tab-pane inner fade in notop" id="reviews">
							<?php echo $_smarty_tpl->tpl_vars['MODULE_products_reviews']->value;?>

						</div>

					</div>
				</div>
			</div>
		</div>

		<?php if ($_smarty_tpl->tpl_vars['MODULE_bundle']->value != '') {?>
		<?php echo $_smarty_tpl->tpl_vars['MODULE_bundle']->value;?>

		<?php }?>
		
		<?php if ($_smarty_tpl->tpl_vars['MODULE_products_media']->value != '') {?>
		<?php echo $_smarty_tpl->tpl_vars['MODULE_products_media']->value;?>

		<?php }?>
		
		<?php if ($_smarty_tpl->tpl_vars['MODULE_cross_selling']->value != '') {?>
		<?php echo $_smarty_tpl->tpl_vars['MODULE_cross_selling']->value;?>

		<?php }?>
		
		<?php if ($_smarty_tpl->tpl_vars['MODULE_reverse_cross_selling']->value != '') {?>
		<?php echo $_smarty_tpl->tpl_vars['MODULE_reverse_cross_selling']->value;?>

		<?php }?>
		
		<?php if ($_smarty_tpl->tpl_vars['MODULE_also_purchased']->value != '') {?>
		<?php echo $_smarty_tpl->tpl_vars['MODULE_also_purchased']->value;?>

		<?php }?>

</div><?php }
}
