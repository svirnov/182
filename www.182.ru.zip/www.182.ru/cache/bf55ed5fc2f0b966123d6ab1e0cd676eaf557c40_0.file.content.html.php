<?php
/* Smarty version 3.1.30, created on 2016-09-05 11:46:47
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\content.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd30f7e8b251_41789268',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf55ed5fc2f0b966123d6ab1e0cd676eaf557c40' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\content.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd30f7e8b251_41789268 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Заголовок страницы -->
<h1><?php echo $_smarty_tpl->tpl_vars['CONTENT_HEADING']->value;?>
</h1>
<!-- /Заголовок страницы -->
<!-- Скругленные углы -->
<div class="page">
<!-- Содержимое страницы -->
<div class="pagecontent">

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sub_pages_content']->value, 'sub_pages', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['sub_pages']->value) {
?>
&nbsp;&nbsp;&nbsp;<a href="<?php echo $_smarty_tpl->tpl_vars['sub_pages']->value['PAGE_LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['sub_pages']->value['PAGE_TITLE'];?>
</a><br />
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 

<?php if ($_smarty_tpl->tpl_vars['file']->value) {?>
  <?php echo $_smarty_tpl->tpl_vars['file']->value;?>

<?php } else { ?>
<p>
  <?php echo $_smarty_tpl->tpl_vars['CONTENT_BODY']->value;?>

</p>
<?php }?>
</div>
<!-- /Содержимое страницы -->
<!-- /Скругленные углы -->
<div class="pagecontentfooter">
<?php echo $_smarty_tpl->tpl_vars['BUTTON_CONTINUE']->value;?>

</div>
</div><?php }
}
