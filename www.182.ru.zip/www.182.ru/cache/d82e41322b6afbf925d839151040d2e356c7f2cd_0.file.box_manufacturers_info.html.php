<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:08:17
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_manufacturers_info.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd0bd1b34a70_24069940',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd82e41322b6afbf925d839151040d2e356c7f2cd' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_manufacturers_info.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd0bd1b34a70_24069940 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<section class="widget inner">
	<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_manufacturers_info');?>
</h3>
			<div class="text-center">
				<p>
				<?php if ($_smarty_tpl->tpl_vars['IMAGE']->value) {?><img src="<?php echo $_smarty_tpl->tpl_vars['IMAGE']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['NAME']->value;?>
" /><?php }?>
				</p>
				<p>
				<?php echo $_smarty_tpl->tpl_vars['NAME']->value;?>

				</p>
				<p>
				<?php if ($_smarty_tpl->tpl_vars['URL']->value) {
echo $_smarty_tpl->tpl_vars['URL']->value;
}?>
				</p>
				<p>
				<?php echo $_smarty_tpl->tpl_vars['LINK_MORE']->value;?>

				</p>
			</div>
</section><?php }
}
