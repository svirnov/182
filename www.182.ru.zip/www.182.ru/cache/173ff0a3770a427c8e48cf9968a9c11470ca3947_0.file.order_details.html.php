<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:54:32
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\order_details.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f4786acfc6_00638744',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '173ff0a3770a427c8e48cf9968a9c11470ca3947' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\order_details.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f4786acfc6_00638744 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "shopping_cart", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "product_info", 0);
?>


<table width="100%" border="0" cellspacing="0" cellpadding="3">
  <tr> 
    <td>&nbsp;</td>
    <td align="center"><strong><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_qty');?>
</strong></td>
    <td><strong>&nbsp;&nbsp;<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_article');?>
</strong></td>
    <td align="right"><strong><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_single');?>
</strong></td>
    <td align="right"><strong><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_total');?>
</strong></td>
    <td align="center"><strong>&nbsp;<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_remove');?>
&nbsp;</strong></td>
  </tr>
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_content']->value, 'module_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['module_data']->value) {
?> 
  <tr> 
    <td colspan="6"></td>
  </tr>
  <tr> 
    <td><?php if ($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_IMAGE'] != '') {?><img src="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_IMAGE'];?>
" width="100" alt="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['IMAGE_ALT'];?>
" /><?php }?></td>
    <td valign="top" align="center"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_QTY'];?>
</td>
    <td valign="top"><strong><a href="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_NAME'];?>
</a></strong><br />
      <?php if ($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SHIPPING_TIME'] != '') {
echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_shippingtime');?>
&nbsp;<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SHIPPING_TIME'];
}?>
      <?php if ($_smarty_tpl->tpl_vars['module_data']->value['ATTRIBUTES'] != '') {?> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_data']->value['ATTRIBUTES'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?> 
        <tr> 
          <td><?php echo $_smarty_tpl->tpl_vars['item_data']->value['NAME'];?>
:</td>
          <td align="left"><?php echo $_smarty_tpl->tpl_vars['item_data']->value['VALUE_NAME'];?>
</td>
        </tr>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 
      </table>
      <?php } else { ?>
      <?php }?> </td>
    <td valign="top" align="right"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SINGLE_PRICE'];?>
</td>
    <td valign="top" align="right"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_PRICE'];?>
&nbsp; 
    </td>
    <td width="10" align="center" valign="middle"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['BOX_DELETE'];?>
</td>
  </tr>
  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 
  <tr> 
    <td colspan="6"></td>
  </tr>
  <tr> 
    <td colspan="6" align="right"><?php echo $_smarty_tpl->tpl_vars['UST_CONTENT']->value;?>
<strong><?php echo $_smarty_tpl->tpl_vars['TOTAL_CONTENT']->value;?>
</strong><?php if ($_smarty_tpl->tpl_vars['SHIPPING_INFO']->value) {
echo $_smarty_tpl->tpl_vars['SHIPPING_INFO']->value;
}?></td>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
</table><?php }
}
