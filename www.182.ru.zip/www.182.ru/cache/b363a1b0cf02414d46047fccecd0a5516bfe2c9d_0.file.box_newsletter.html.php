<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:27
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_newsletter.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fb07a128_61417039',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b363a1b0cf02414d46047fccecd0a5516bfe2c9d' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_newsletter.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fb07a128_61417039 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<section class="widget inner">
	<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_guestnewsletter');?>
</h3>
		<?php echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>

			<div class="control-group">
			<label class="control-label" for="inputEmail"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_email');?>
</label>
				<div class="controls">
					<input type="text" name="email" id="newsletter_email" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_email');?>
">
				</div>
			</div>
			<div class="control-group">
				<div class="controls">
					<button type="submit" class="btn btn-inverse"><i class="fa fa-check"></i> <?php echo @constant('IMAGE_BUTTON_CONTINUE');?>
</button>
				</div>
			</div>
		<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;?>

</section><?php }
}
