<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:08:17
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\products_reviews.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd0bd1e11133_26647870',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '526e9ec43584bb4c5837eaa59512286233396f47' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\products_reviews.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd0bd1e11133_26647870 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_number_format')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins_vam\\modifier.number_format.php';
if (!is_callable('smarty_modifier_date_format')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins\\modifier.date_format.php';
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "reviews", 0);
?>
<br />
<h1><?php echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;?>
 <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_reviews');?>
</h1>
<div class="row-fluid reviews-title" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
	<div class="span8 title">
	<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_reviews');?>
 <span itemprop="reviewCount"><?php echo $_smarty_tpl->tpl_vars['PRODUCTS_REVIEWS_COUNT']->value;?>
</span>, <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_rating');?>
 <span itemprop="ratingValue"><?php echo smarty_modifier_number_format($_smarty_tpl->tpl_vars['PRODUCTS_REVIEWS_RATING']->value,2);?>
</span>
	</div>	
</div>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_content']->value, 'module_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['module_data']->value) {
?> 
<div class="page">
<div class="pagecontent" itemprop="review" itemscope itemtype="http://schema.org/Review">

<p>
<span class="bold"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_author');?>
</span> <span itemprop="author" itemscope itemtype="http://schema.org/Person"><span itemprop="name"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['AUTHOR'];?>
</span></span> <span content="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['module_data']->value['DATE'],"%Y-%m-%d");?>
" itemprop="datePublished"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['module_data']->value['DATE'],"%Y-%m-%d");?>
</span>
</p>

<meta itemprop="itemReviewed" content="<?php echo $_smarty_tpl->tpl_vars['PRODUCTS_NAME']->value;?>
">

<p>
<span class="bold"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_rating');?>
</span> <span itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating"><span itemprop="ratingValue" content="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['RATING_TXT'];?>
"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['RATING_TXT'];?>
</span></span> <?php echo $_smarty_tpl->tpl_vars['module_data']->value['RATING'];?>

</p>

<p itemprop="reviewBody">
<?php echo $_smarty_tpl->tpl_vars['module_data']->value['TEXT'];?>

</p>
      
</div>
</div>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


<?php if ($_smarty_tpl->tpl_vars['TEXT_FIRST_REVIEW']->value != '') {?>
<div class="page">
<div class="pagecontent">
<p>
<?php echo $_smarty_tpl->tpl_vars['TEXT_FIRST_REVIEW']->value;?>

</p>
</div>
</div>
<?php }?>
<div class="pagecontentfooter">
<?php echo $_smarty_tpl->tpl_vars['BUTTON_WRITE']->value;?>

</div>
<?php }
}
