<?php
/* Smarty version 3.1.30, created on 2016-09-05 11:46:55
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\account.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd30ffaba958_72957112',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6f202c7d68ee71bb29b9c9cb764b12b638351163' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\account.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd30ffaba958_72957112 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "account", 0);
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_account');?>
</h1>
<!-- Приветствие -->
<?php echo $_smarty_tpl->tpl_vars['error_message']->value;?>

<div class="page">
<div class="pagecontent">
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_welcome');?>

</p>
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_welcome');?>

</p>
<?php if ($_smarty_tpl->tpl_vars['LINK_LOGIN']->value) {?>
<ul class="accountLinks">
<li class="accountLinks"><a href="<?php echo $_smarty_tpl->tpl_vars['LINK_LOGIN']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_login');?>
</a></li>
</ul>
<?php }?>
</div>
</div>
<!-- /Приветствие -->

<!-- Личные данные -->
<div class="page">
<div class="pagecontent">
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_account');?>

</p>
<ul class="accountLinks">
<li class="accountLinks"><a href="<?php echo $_smarty_tpl->tpl_vars['LINK_EDIT']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_edit');?>
</a></li>
<li class="accountLinks"><a href="<?php echo $_smarty_tpl->tpl_vars['LINK_ADDRESS']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_address');?>
</a></li>
<li class="accountLinks"><a href="<?php echo $_smarty_tpl->tpl_vars['LINK_PASSWORD']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_password');?>
</a></li>
</ul>
</div>
</div>
<!-- /Личные данные -->

<?php if ($_smarty_tpl->tpl_vars['order_content']->value) {?>
<!-- Заказы -->
<div class="page">
<div class="pagecontent">
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_orders');?>
&nbsp;<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_ALL']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_all');?>
</a>
</p>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['order_content']->value, 'order_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['order_data']->value) {
?> 
<p>
<a href="<?php echo $_smarty_tpl->tpl_vars['order_data']->value['ORDER_LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['order_data']->value['ORDER_DATE'];?>
</a>&nbsp;&nbsp;<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'order_nr');?>
 <?php echo $_smarty_tpl->tpl_vars['order_data']->value['ORDER_ID'];?>

</p>
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'order_total');?>
 <?php echo $_smarty_tpl->tpl_vars['order_data']->value['ORDER_TOTAL'];?>
&nbsp;&nbsp;<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'order_status');?>
 <?php echo $_smarty_tpl->tpl_vars['order_data']->value['ORDER_STATUS'];?>
 
</p>
<p>
<?php echo $_smarty_tpl->tpl_vars['order_data']->value['ORDER_BUTTON'];?>

</p>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 
</div>
</div>
<!-- /Заказы -->
<?php }?>

<!-- Уведомления -->
<div class="page">
<div class="pagecontent">
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_notification');?>

</p>
<ul class="accountLinks">
<li class="accountLinks"><a href="<?php echo $_smarty_tpl->tpl_vars['LINK_NEWSLETTER']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_newsletter');?>
</a></li>
</ul>
</div>
</div>
<!-- /Уведомления -->

<?php if ($_smarty_tpl->tpl_vars['products_history']->value) {?>
<!-- Просмотренные товары -->
<div class="page">
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'title_viewed_products');?>

</p>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products_history']->value, 'products', false, NULL, 'history_products', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['products']->value) {
?> 
<dl class="itemLastViewed">
<dt class="itemImage">
<?php if ($_smarty_tpl->tpl_vars['products_history']->value['PRODUCTS_IMAGE'] != '') {?><a href="<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_LINK'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_IMAGE'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_NAME'];?>
" border="0" /></a><?php }?>
</dt>
<dd class="itemDescription">
<a href="<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_NAME'];?>
</a>
</dd>

<?php if ($_smarty_tpl->tpl_vars['products_history']->value['REVIEWS_TOTAL'] > 0) {?><dd class="itemDescription"><span class="rating"><?php echo $_smarty_tpl->tpl_vars['products']->value['REVIEWS_STAR_RATING'];?>
</span>, <span class="reviews"><?php echo @constant('TEXT_TOTAL_REVIEWS');?>
: <?php echo $_smarty_tpl->tpl_vars['products']->value['REVIEWS_TOTAL'];?>
</span></dd><?php }?>

<dd class="itemDescriptionPrice">
<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_PRICE'];?>

</dd>

<?php if ($_smarty_tpl->tpl_vars['products_history']->value['PRODUCTS_VPE']) {?>
<dd class="itemDescription">
<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_VPE'];?>

</dd>
<?php }?>

<dd class="itemDescription">
<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_TAX_INFO'];
echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_SHIPPING_LINK'];?>

</dd>

<dd class="itemDescription">
<a href="<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_LINK'];?>
"></a><a href="<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_CATEGORY_URL'];?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_goto_cat');?>
</a>
</dd>

<dd class="itemDescription">
<?php echo $_smarty_tpl->tpl_vars['products']->value['PRODUCTS_BUTTON_BUY_NOW'];?>

</dd>

</dl>
          <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 

</div>
<div class="clear"></div>
<!-- /Просмотренные товары -->
<?php }
}
}
