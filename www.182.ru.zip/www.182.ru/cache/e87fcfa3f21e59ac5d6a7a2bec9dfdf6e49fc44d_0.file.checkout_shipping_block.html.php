<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:54:38
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\checkout_shipping_block.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f47e66ff37_11126543',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e87fcfa3f21e59ac5d6a7a2bec9dfdf6e49fc44d' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\checkout_shipping_block.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f47e66ff37_11126543 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_cycle')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins\\function.cycle.php';
?>
 <?php if ($_smarty_tpl->tpl_vars['FREE_SHIPPING']->value) {?> 
<p>
<span class="bold"><?php echo $_smarty_tpl->tpl_vars['FREE_SHIPPING_TITLE']->value;?>
</span>&nbsp;<?php echo $_smarty_tpl->tpl_vars['FREE_SHIPPING_ICON']->value;?>
</span>
</p>
<p>
<?php echo $_smarty_tpl->tpl_vars['FREE_SHIPPING_DESCRIPTION']->value;?>

</p>
<?php } else { ?> 
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_content']->value, 'module_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['module_data']->value) {
?>
<div class="<?php echo smarty_function_cycle(array('values'=>"itemOdd,itemEven"),$_smarty_tpl);?>
">   
<p>
<?php echo $_smarty_tpl->tpl_vars['module_data']->value['icon'];?>
 <span class="bold"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['module'];?>
</span>
</p>
<!-- QIWI Post code begin -->
<?php if ($_smarty_tpl->tpl_vars['module_data']->value['id'] == 'qiwipost') {
echo $_smarty_tpl->tpl_vars['module_data']->value['qiwipost'];?>

<?php }?>
<!-- QIWI Post code end -->

<?php if ($_smarty_tpl->tpl_vars['module_data']->value['error'] != '') {?>
<p>
<?php echo $_smarty_tpl->tpl_vars['module_data']->value['error'];?>

</p>
<?php } else { ?> 
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_data']->value['methods'], 'method_data', false, NULL, 'aussen', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['method_data']->value) {
?> 
<p>
<label for="<?php echo $_smarty_tpl->tpl_vars['method_data']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['method_data']->value['radio_field'];?>
&nbsp;<?php echo $_smarty_tpl->tpl_vars['method_data']->value['title'];?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['method_data']->value['price'];?>
</label>
</p> 
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<?php }?>
</div>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<?php }
}
}
