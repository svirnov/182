<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:26
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_whatsnew.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fae11138_51258608',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c7f341c078a08b85c09d979e3cee10339e6800a1' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_whatsnew.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fae11138_51258608 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<section class="widget inner">
	<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_whatsnew');?>
</h3>
			<div class="text-center">

				<?php if ($_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_IMAGE']) {?>
				<p>
				<a href="<?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_LINK'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_IMAGE'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_NAME'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_NAME'];?>
" /></a>
				</p>
				<?php }?>
				
				<p>
				<a href="<?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_NAME'];?>
</a>
				</p>

				<?php if ($_smarty_tpl->tpl_vars['box_content']->value['REVIEWS_TOTAL'] > 0) {?><p><span class="rating"><?php echo $_smarty_tpl->tpl_vars['box_content']->value['REVIEWS_STAR_RATING'];?>
</span> <span class="reviews"><?php echo @constant('TEXT_TOTAL_REVIEWS');?>
: <?php echo $_smarty_tpl->tpl_vars['box_content']->value['REVIEWS_TOTAL'];?>
</span></p><?php }?>
				
				<p>
				<?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_PRICE'];?>

				</p>
				
				<?php if ($_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_VPE']) {?><p><?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_VPE'];?>
</p><?php }?>
				
				<?php if ($_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_SHIPPING_LINK']) {?>
				<p>
				<?php echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_TAX_INFO'];
echo $_smarty_tpl->tpl_vars['box_content']->value['PRODUCTS_SHIPPING_LINK'];?>

				</p>
				<?php }?>

			</div>
</section><?php }
}
