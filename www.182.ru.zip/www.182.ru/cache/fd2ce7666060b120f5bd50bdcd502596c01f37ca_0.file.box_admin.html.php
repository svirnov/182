<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:42
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_admin.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd0a0a81b328_29542189',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fd2ce7666060b120f5bd50bdcd502596c01f37ca' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_admin.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd0a0a81b328_29542189 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<section class="widget inner">
	<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_admin');?>
</h3>
			<div class="text-left">
					<?php echo $_smarty_tpl->tpl_vars['BOX_CONTENT']->value;?>

			</div>
</section>
<?php }
}
