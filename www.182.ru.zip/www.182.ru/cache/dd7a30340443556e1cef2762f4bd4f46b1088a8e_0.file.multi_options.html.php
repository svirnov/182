<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:08:17
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\product_options\multi_options.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd0bd1d97014_83218520',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dd7a30340443556e1cef2762f4bd4f46b1088a8e' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\product_options\\multi_options.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd0bd1d97014_83218520 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['options']->value != '') {
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options']->value, 'options_data', false, NULL, 'outer', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['options_data']->value) {
if ($_smarty_tpl->tpl_vars['options_data']->value['TYPE'] == '1') {?>

<!-- select -->
<p>
<strong><?php echo $_smarty_tpl->tpl_vars['options_data']->value['NAME'];?>
:</strong>
<select name="id[<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
]">
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options_data']->value['DATA'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?>
<option value="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
"><?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
   <?php if ($_smarty_tpl->tpl_vars['item_data']->value['MODEL']) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['MODEL'];?>
)<?php }?> <?php if ($_smarty_tpl->tpl_vars['item_data']->value['PRICE_PLAIN'] != 0) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['PREFIX'];
echo $_smarty_tpl->tpl_vars['item_data']->value['PRICE'];?>
)<?php }?></option>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</select>
</p>
<!-- /select -->

<?php } elseif ($_smarty_tpl->tpl_vars['options_data']->value['TYPE'] == '2') {?>

<!-- text -->
<p>

<strong><?php echo $_smarty_tpl->tpl_vars['options_data']->value['NAME'];?>
:</strong>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options_data']->value['DATA'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?>
<strong><?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
</strong>
<input name="id[<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
]" type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
" />
<input name="id[txt_<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
_<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
]" type="text" size="<?php echo $_smarty_tpl->tpl_vars['options_data']->value['SIZE'];?>
" maxlength="<?php echo $_smarty_tpl->tpl_vars['options_data']->value['LENGTH'];?>
" /><?php if ($_smarty_tpl->tpl_vars['item_data']->value['MODEL']) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['MODEL'];?>
)<?php }?> <?php if ($_smarty_tpl->tpl_vars['item_data']->value['PRICE_PLAIN'] != 0) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['PREFIX'];
echo $_smarty_tpl->tpl_vars['item_data']->value['PRICE'];?>
)<?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION']) {?><br /><?php echo $_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION'];
}?><br />
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</p>
<!-- /text -->

<?php } elseif ($_smarty_tpl->tpl_vars['options_data']->value['TYPE'] == '3') {?>

<!-- textarea -->
<p>
<strong><?php echo $_smarty_tpl->tpl_vars['options_data']->value['NAME'];?>
:</strong>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options_data']->value['DATA'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?>
<strong><?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
</strong>
<input name="id[<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
]" type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
" />
<textarea name="id[txt_<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
_<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
]" cols="20" rows="<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ROWS'];?>
"></textarea>
<?php if ($_smarty_tpl->tpl_vars['item_data']->value['MODEL']) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['MODEL'];?>
)<?php }?> <?php if ($_smarty_tpl->tpl_vars['item_data']->value['PRICE_PLAIN'] != 0) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['PREFIX'];
echo $_smarty_tpl->tpl_vars['item_data']->value['PRICE'];?>
)<?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION']) {?><br /><?php echo $_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION'];
}?><br />
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</p>
<!-- /textarea -->

<?php } elseif ($_smarty_tpl->tpl_vars['options_data']->value['TYPE'] == '4') {?>

<!-- radio -->
<p>
<strong><?php echo $_smarty_tpl->tpl_vars['options_data']->value['NAME'];?>
:</strong>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options_data']->value['DATA'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?>
<!-- changed by mosq // -->
<input type="radio" name="id[<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
]" value="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
" <?php echo $_smarty_tpl->tpl_vars['item_data']->value['CHECKED'];?>
 />

<?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
 <?php if ($_smarty_tpl->tpl_vars['item_data']->value['PRICE_PLAIN'] != 0) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['PREFIX'];
echo $_smarty_tpl->tpl_vars['item_data']->value['PRICE'];?>
)<?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION']) {?><br /><?php echo $_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION'];?>
<br /><?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['SHORT_DESCRIPTION']) {
echo $_smarty_tpl->tpl_vars['item_data']->value['SHORT_DESCRIPTION'];?>
<br /><?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['IMAGE']) {?><img src="<?php echo $_smarty_tpl->tpl_vars['image_dir']->value;?>
thumbs/<?php echo $_smarty_tpl->tpl_vars['item_data']->value['IMAGE'];?>
" border="0" alt="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
" /><?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['LINK']) {?><a align="right" href="http://<?php echo $_smarty_tpl->tpl_vars['item_data']->value['LINK'];?>
" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['tpl_path']->value;?>
img/info.gif" border="0" alt="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
" /></a><?php }?><br />
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</p>
<!-- /radio -->

<?php } elseif ($_smarty_tpl->tpl_vars['options_data']->value['TYPE'] == '5') {?>

<!-- checkbox -->
<p>
<strong><?php echo $_smarty_tpl->tpl_vars['options_data']->value['NAME'];?>
:</strong>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options_data']->value['DATA'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?>
<input type="checkbox" name="id[<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
]" value="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
" />
<?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
 <?php if ($_smarty_tpl->tpl_vars['item_data']->value['PRICE_PLAIN'] != 0) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['PREFIX'];
echo $_smarty_tpl->tpl_vars['item_data']->value['PRICE'];?>
)<?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION']) {?><br /><?php echo $_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION'];
}?><br />
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</p>
<!-- /checkbox -->

<?php } elseif ($_smarty_tpl->tpl_vars['options_data']->value['TYPE'] == '6') {?>

<!-- readonly -->
<p>
<strong><?php echo $_smarty_tpl->tpl_vars['options_data']->value['NAME'];?>
:</strong>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options_data']->value['DATA'], 'item_data', false, 'key_data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key_data']->value => $_smarty_tpl->tpl_vars['item_data']->value) {
?>
<input type="hidden" name="id[<?php echo $_smarty_tpl->tpl_vars['options_data']->value['ID'];?>
]" value="<?php echo $_smarty_tpl->tpl_vars['item_data']->value['ID'];?>
" />
<?php if ($_smarty_tpl->tpl_vars['item_data']->value['MODEL']) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['MODEL'];?>
)<?php }?> <?php echo $_smarty_tpl->tpl_vars['item_data']->value['TEXT'];?>
 <?php if ($_smarty_tpl->tpl_vars['item_data']->value['PRICE_PLAIN'] != 0) {?>(<?php echo $_smarty_tpl->tpl_vars['item_data']->value['PREFIX'];
echo $_smarty_tpl->tpl_vars['item_data']->value['PRICE'];?>
)<?php }
if ($_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION']) {?><br /><?php echo $_smarty_tpl->tpl_vars['item_data']->value['DESCRIPTION'];
}?><br />

<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</p>
<!-- /readonly -->

<?php }
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

<?php }
}
}
