<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:27
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_infobox.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fb000007_91555801',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '06400518af791a1061eca02ac221298cfd5aaab5' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_infobox.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fb000007_91555801 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<section class="widget inner">
	<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_customer_group_info');?>
</h3>
			<div class="text-center">
					<?php echo $_smarty_tpl->tpl_vars['BOX_CONTENT']->value;?>

			</div>
</section>
<?php }
}
