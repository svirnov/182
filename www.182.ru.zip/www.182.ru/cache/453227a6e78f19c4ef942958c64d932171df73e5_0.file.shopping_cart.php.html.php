<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:54:32
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\shopping_cart.php.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f478d59f80_08588776',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '453227a6e78f19c4ef942958c64d932171df73e5' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\shopping_cart.php.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f478d59f80_08588776 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "index", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>


<!-- start: Header -->
<div id="header">
	<div class="container">
		<div class="row-fluid">
			<div class="span3 logo">
				<a href="<?php echo $_smarty_tpl->tpl_vars['mainpage']->value;?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['tpl_path']->value;?>
img/logo.png" alt="<?php echo @constant('STORE_NAME');?>
" title="<?php echo @constant('STORE_NAME');?>
" /></a>
			</div>
			<div class="span6 text-center">
           <br />
           <h4><?php echo @constant('STORE_TELEPHONE');?>
</h4>
           <h4><a href="contact_us.html"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_contact_us');?>
</a></h4>
			</div>
			<div class="span3 text-center">
			</div>
		</div>
	</div>
</div>
<!-- end: Header -->

<!-- start: Main Menu -->
<div id="navigation" class="default">
	<div class="container">
            <div class="navbar">
              <div class="navbar-inner">
                <div class="container">
                  <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </a>
					     <a class="brand" href="<?php echo @constant('FILENAME_DEFAULT');?>
">
					         <i class="fa fa-home"></i>
					     </a>                  
					     <div class="nav-collapse collapse navbar-responsive-collapse">
                    <ul class="nav">
							<?php echo $_smarty_tpl->tpl_vars['box_CATEGORIES2']->value;?>

							<li class="dropdown">
								<a data-toggle="dropdown" class="dropdown-toggle" href=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_infobox');?>
 <b class="caret"></b></a>
								<ul class="dropdown-menu">
									<?php echo $_smarty_tpl->tpl_vars['box_CONTENT_PULL']->value;?>

								</ul>
							</li>
                    </ul>
                    <form class="navbar-search pull-left" action="advanced_search_result.php" method="get">
                      <input type="text" name="keywords" class="search-query span2" placeholder="<?php echo @constant('BOX_HEADING_SEARCH');?>
">
                    </form>
                    <ul class="nav pull-right">
                      <li><a href="<?php echo @constant('FILENAME_ACCOUNT');?>
"><i class="fa fa-user"></i> <?php echo @constant('TEXT_MY_ORDERS');?>
</a></li>
                      <li class="dropdown"><a data-toggle="dropdown" class="dropdown-toggle cart" data-target="#" href="<?php echo @constant('FILENAME_SHOPPING_CART');?>
" title="<?php echo @constant('NAVBAR_TITLE_SHOPPING_CART');?>
"> <i class="fa fa-shopping-cart"></i> <?php echo @constant('NAVBAR_TITLE_SHOPPING_CART');?>
 <?php if ($_smarty_tpl->tpl_vars['cart_count']->value > 0) {?><sup><span title="<?php echo $_smarty_tpl->tpl_vars['cart_count']->value;?>
" class="badge badge-important"><?php echo $_smarty_tpl->tpl_vars['cart_count']->value;?>
</span></sup><?php }?> <b class="caret"></b></a>
                        <ul class="dropdown-menu cart">
                           <li><div id="divShoppingCart"><?php echo $_smarty_tpl->tpl_vars['box_CART_PULL']->value;?>
</div></li>
                        </ul>                        
                      </li>
                      <?php if ($_SESSION['customers_status']['customers_status_id'] == 0) {?>
                      <li><a href="<?php echo $_smarty_tpl->tpl_vars['admin_area_link']->value;?>
"><i class="fa fa-gear"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_admin');?>
</a></li>
                      <?php }?>  
                      <?php if ($_SESSION['customer_id']) {?>
                      <li><a href="<?php echo $_smarty_tpl->tpl_vars['logoff']->value;?>
"><i class="fa fa-power-off"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'link_logoff');?>
</a></li>
                      <?php }?>  
                    </ul>
                  </div><!-- /.nav-collapse -->
                </div>
              </div><!-- /navbar-inner -->
            </div><!-- /navbar -->
	</div>
</div>
<!-- end: Main Menu -->

<!-- start: Container -->
<div id="container">
	<div class="container">

		<div class="row-fluid">

			<!-- start: Page section -->
			<div class="span9 page-sidebar pull-right">
	
			<?php echo $_smarty_tpl->tpl_vars['main_content']->value;?>


			</div>
			<!-- end: Page section -->

		<!-- start: Sidebar -->
		<aside class="span3 sidebar pull-left">

			<?php echo $_smarty_tpl->tpl_vars['box_CONTENT']->value;?>


		</aside>
		<!-- end: Sidebar -->

		</div>

	</div>
</div>
<!-- end: Container -->
<?php }
}
