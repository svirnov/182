<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:26
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\boxes\box_content_pull.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09faec82e6_57627589',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8390b7f06f8a7496bdfa26018caceee65a4cba83' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\boxes\\box_content_pull.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09faec82e6_57627589 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "index", 0);
?>

<?php echo $_smarty_tpl->tpl_vars['BOX_CONTENT_PULL']->value;?>

<?php }
}
