<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:00:27
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\index.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd09fb6acfc9_60898671',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a5e68a09ab7336048555f3487ce04238da24dd0c' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\index.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd09fb6acfc9_60898671 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "index", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "boxes", 0);
?>


<!-- start: Header -->
<div id="header">
	<div class="container">
		<div class="row-fluid">
			<div class="span3 logo">
				<a href="<?php echo $_smarty_tpl->tpl_vars['mainpage']->value;?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['tpl_path']->value;?>
img/logo.png" alt="<?php echo @constant('STORE_NAME');?>
" title="<?php echo @constant('STORE_NAME');?>
" /></a>
			</div>
			<div class="span6 text-center">
           <br />
           <h4><?php echo @constant('STORE_TELEPHONE');?>
</h4>
           <h4><a href="contact_us.html"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_contact_us');?>
</a></h4>
			</div>
			<div class="span3 text-center">
			</div>
		</div>
	</div>
</div>
<!-- end: Header -->

<!-- start: Main Menu -->
<div id="navigation" class="default">
	<div class="container">
            <div class="navbar">
              <div class="navbar-inner">
                <div class="container">
                  <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </a>
					     <a class="brand" href="<?php echo @constant('FILENAME_DEFAULT');?>
">
					         <i class="fa fa-home"></i>
					     </a>                  
					     <div class="nav-collapse collapse navbar-responsive-collapse">
                    <ul class="nav">
							<?php echo $_smarty_tpl->tpl_vars['box_CATEGORIES2']->value;?>

							<li class="dropdown">
								<a data-toggle="dropdown" class="dropdown-toggle" href=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_infobox');?>
 <b class="caret"></b></a>
								<ul class="dropdown-menu">
									<?php echo $_smarty_tpl->tpl_vars['box_CONTENT_PULL']->value;?>

								</ul>
							</li>
                    </ul>
                    <form class="navbar-search pull-left" action="advanced_search_result.php" method="get">
                      <input type="text" name="keywords" class="search-query span2" placeholder="<?php echo @constant('BOX_HEADING_SEARCH');?>
">
                    </form>
                    <ul class="nav pull-right">
                      <li><a href="<?php echo @constant('FILENAME_ACCOUNT');?>
"><i class="fa fa-user"></i> <?php echo @constant('TEXT_MY_ORDERS');?>
</a></li>
                      <li class="dropdown"><a data-toggle="dropdown" class="dropdown-toggle cart" data-target="#" href="<?php echo @constant('FILENAME_SHOPPING_CART');?>
" title="<?php echo @constant('NAVBAR_TITLE_SHOPPING_CART');?>
"> <i class="fa fa-shopping-cart"></i> <?php echo @constant('NAVBAR_TITLE_SHOPPING_CART');?>
 <?php if ($_smarty_tpl->tpl_vars['cart_count']->value > 0) {?><sup><span title="<?php echo $_smarty_tpl->tpl_vars['cart_count']->value;?>
" class="badge badge-important"><?php echo $_smarty_tpl->tpl_vars['cart_count']->value;?>
</span></sup><?php }?> <b class="caret"></b></a>
                        <ul class="dropdown-menu cart">
                           <li><div id="divShoppingCart"><?php echo $_smarty_tpl->tpl_vars['box_CART_PULL']->value;?>
</div></li>
                        </ul>                        
                      </li>
                      <?php if ($_SESSION['customers_status']['customers_status_id'] == 0) {?>
                      <li><a href="<?php echo $_smarty_tpl->tpl_vars['admin_area_link']->value;?>
"><i class="fa fa-gear"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_admin');?>
</a></li>
                      <?php }?>  
                      <?php if ($_SESSION['customer_id']) {?>
                      <li><a href="<?php echo $_smarty_tpl->tpl_vars['logoff']->value;?>
"><i class="fa fa-power-off"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'link_logoff');?>
</a></li>
                      <?php }?>  
                    </ul>
                  </div><!-- /.nav-collapse -->
                </div>
              </div><!-- /navbar-inner -->
            </div><!-- /navbar -->
	</div>
</div>
<!-- end: Main Menu -->

<?php if ($_smarty_tpl->tpl_vars['navtrail']->value) {?>
<!-- start: Page header / Breadcrumbs -->
<div id="breadcrumbs">
	<div class="container">
		<div class="breadcrumbs">
			<?php echo $_smarty_tpl->tpl_vars['navtrail']->value;?>

		</div>
	</div>
</div>
<!-- end: Page header / Breadcrumbs -->
<?php }?>

<!-- start: Container -->
<div id="container">
	<div class="container">

		<div class="row-fluid">

			<!-- start: Page section -->
			<div class="span9 page-sidebar pull-right">
	
			<?php echo $_smarty_tpl->tpl_vars['main_content']->value;?>


			</div>
			<!-- end: Page section -->

		<!-- start: Sidebar -->
		<aside class="span3 sidebar pull-left">
         <?php echo $_smarty_tpl->tpl_vars['box_SEARCH']->value;?>
			
			<?php echo $_smarty_tpl->tpl_vars['box_CART']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_DOWNLOADS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_CATEGORIES']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_FILTERS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_CONTENT']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_INFORMATION']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_LOGIN']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_ADMIN']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_ADD_QUICKIE']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_LAST_VIEWED']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_REVIEWS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_SPECIALS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_FEATURED']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_LATESTNEWS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_ARTICLES']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_ARTICLESNEW']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_AUTHORS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_AFFILIATE']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_WHATSNEW']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_NEWSLETTER']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_BESTSELLERS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_INFOBOX']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_CURRENCIES']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_LANGUAGES']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_MANUFACTURERS']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_MANUFACTURERS_INFO']->value;?>

			<?php echo $_smarty_tpl->tpl_vars['box_FAQ']->value;?>


		</aside>
		<!-- end: Sidebar -->

		</div>

	</div>
</div>
<!-- end: Container -->

<!-- start: Footer -->
<footer id="footer">
	<div class="container">
		<div class="row-fluid">
			<div class="span3 clearfix">
				<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_infobox');?>
</h3>
				<div class="widget-inner">

					<ul class="unstyled">
						<?php echo $_smarty_tpl->tpl_vars['box_CONTENT_PULL']->value;?>

					</ul>

				</div>
			</div>
			<div class="span3 clearfix">
				<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_news');?>
</h3>
				<div class="widget-inner">

					<ul class="unstyled">
						<?php echo $_smarty_tpl->tpl_vars['box_LATESTNEWS_DROPDOWN']->value;?>

					</ul>

				</div>
			</div>

			<div class="span6 clearfix">
				<h3 class="widget-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_articles_new');?>
</h3>
				<div class="widget-inner">

					<ul class="unstyled">
						<?php echo $_smarty_tpl->tpl_vars['box_ARTICLESNEW_DROPDOWN']->value;?>

					</ul>

				</div>
			</div>
		</div>
	</div>
</footer>
<!-- end: Footer -->

<!-- start: Footer menu -->
<div id="footer-menu">
	<div class="container">
		<div class="row-fluid">
			<div class="span6">
				<ul class="privacy inline">
					<li><a href="about_us.html"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_about_us');?>
</a></li>
					<li><a href="contact_us.html"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_contact_us');?>
</a></li>
				</ul>

			</div>
		</div>
	</div>

	<?php if ($_smarty_tpl->tpl_vars['BANNER']->value) {?><div class="text-center"><?php echo $_smarty_tpl->tpl_vars['BANNER']->value;?>
<br /><br /></div><?php }?>

	<div class="text-center"><a href="vam_rss2_info.php"><img src="images/rss.png" alt="RSS" /></a></div>
</div>
<!-- end: Footer menu --><?php }
}
