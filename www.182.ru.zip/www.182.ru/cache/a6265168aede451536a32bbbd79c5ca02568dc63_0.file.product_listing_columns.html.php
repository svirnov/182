<?php
/* Smarty version 3.1.30, created on 2016-09-05 09:05:51
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\product_listing\product_listing_columns.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57cd0b3f9c6711_24454174',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a6265168aede451536a32bbbd79c5ca02568dc63' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\product_listing\\product_listing_columns.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57cd0b3f9c6711_24454174 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_vam_truncate')) require_once 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\includes\\external\\smarty\\plugins_vam\\modifier.vam_truncate.php';
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "index", 0);
?>

<?php if ($_smarty_tpl->tpl_vars['CATEGORIES_NAME']->value) {?>
<h1><?php echo $_smarty_tpl->tpl_vars['CATEGORIES_NAME']->value;?>
</h1>
<?php }
if ($_smarty_tpl->tpl_vars['CATEGORIES_HEADING_TITLE']->value || $_smarty_tpl->tpl_vars['CATEGORIES_DESCRIPTION']->value) {?>
<div class="page">
<div class="pageItem">

<?php if ($_smarty_tpl->tpl_vars['CATEGORIES_HEADING_TITLE']->value) {?>
<p>
<?php echo $_smarty_tpl->tpl_vars['CATEGORIES_HEADING_TITLE']->value;?>

</p>
<?php }
if ($_smarty_tpl->tpl_vars['CATEGORIES_DESCRIPTION']->value && !$_GET['page']) {?>
<p>
<?php echo $_smarty_tpl->tpl_vars['CATEGORIES_DESCRIPTION']->value;?>

</p>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['CATEGORIES_IMAGE']->value && !$_GET['page']) {?>
<p>
<img src="<?php echo $_smarty_tpl->tpl_vars['CATEGORIES_IMAGE']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['CATEGORIES_NAME']->value;?>
" /></p>
<?php }?>
<div class="clear"></div>
</div>

</div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['MANUFACTURERS_DESCRIPTION']->value && !$_GET['page']) {?>
<div class="page">
<div class="pageItem">
<p>
<?php echo $_smarty_tpl->tpl_vars['MANUFACTURERS_DESCRIPTION']->value;?>

</p>
<div class="clear"></div>
</div>

</div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['CATEGORIES_NAME']->value) {?>
<div class="page">
<div class="pageItem">
<?php echo $_smarty_tpl->tpl_vars['FILTERS']->value;?>

<?php if ($_smarty_tpl->tpl_vars['MANUFACTURER_SORT']->value) {?>
<p>
<?php echo $_smarty_tpl->tpl_vars['MANUFACTURER_SORT']->value;?>

</p>
<?php }?>
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort');?>

<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_name_asc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_name_asc');?>
</a>  
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_name_desc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_name_desc');?>
</a> | 
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_price_asc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_price_asc');?>
</a>  
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_price_desc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_price_desc');?>
</a> | 
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_ordered_asc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_ordered_asc');?>
</a>  
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_ordered_desc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_ordered_desc');?>
</a> |
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_id_asc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_id_asc');?>
</a>  
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_id_desc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_id_desc');?>
</a> | 
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_quantity_asc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_quantity_asc');?>
</a>  
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_sort_quantity_desc']->value;?>
"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_sort_quantity_desc');?>
</a> 
</p>
<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_COUNT']->value >= @constant('MAX_DISPLAY_SEARCH_RESULTS')) {?>
<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_products_per_page');?>


<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_COUNT']->value > 10) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_PAGE']->value;?>
10">10</a> 
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_COUNT']->value > 20) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_PAGE']->value;?>
20">20</a> 
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_COUNT']->value > 50) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_PAGE']->value;?>
50">50</a> 
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['PRODUCTS_COUNT']->value > 100) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['LINK_PAGE']->value;?>
100">100</a>
<?php }?> 
</p>
<?php }?>
<div class="clear"></div>
</div>

</div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['CATEGORIES_NAME']->value) {?>
<form action="<?php echo @constant('FILENAME_COMPARISON');?>
"><?php }?>


<!-- start: products listing -->
<div class="row-fluid shop-products">
	<ul class="thumbnails">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_content']->value, 'module_data', false, NULL, 'aussen', array (
  'index' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['module_data']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_aussen']->value['index']++;
?>
		<li class="item span4<?php if ((isset($_smarty_tpl->tpl_vars['__smarty_foreach_aussen']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_aussen']->value['index'] : null)%3 == 0) {?> first<?php }?>">
			<div class="thumbnail text-center">
				<?php if ($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SPECIAL'] > 0) {?><div class="description"><span class="discount">-<?php echo round($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SPECIAL']);?>
%</span></div><?php }?>
				<a href="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LINK'];?>
" class="image"><img src="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_IMAGE'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_NAME'];?>
" /><span class="frame-overlay"></span><span class="price"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_PRICE'];?>
</span><?php if ($_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LABEL']) {
echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LABEL'];
}?></a>
			<div class="inner notop nobottom text-left">
				<h4 class="title"><a href="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_LINK'];?>
"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_NAME'];?>
</a></h4>
				<?php if ($_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_TOTAL'] > 0) {?><div class="description"><span class="rating"><?php echo $_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_STAR_RATING'];?>
</span> <span class="reviews"><?php echo @constant('TEXT_TOTAL_REVIEWS');?>
: <?php echo $_smarty_tpl->tpl_vars['module_data']->value['REVIEWS_TOTAL'];?>
</span></div><?php }?>
				<div class="description"><?php echo smarty_modifier_vam_truncate(preg_replace('!<[^>]*?>!', ' ', $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_SHORT_DESCRIPTION']),30,"...",true);?>
</div>
				<?php if ($_smarty_tpl->tpl_vars['module_data']->value['EXTRA_FIELDS']) {?>
				<div class="description">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['module_data']->value['EXTRA_FIELDS'], 'extra_fields');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['extra_fields']->value) {
?>
				<?php echo $_smarty_tpl->tpl_vars['extra_fields']->value['NAME'];?>
: <?php echo $_smarty_tpl->tpl_vars['extra_fields']->value['VALUE'];?>
<br />
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				</div>
				<?php }?>
				<?php if ($_smarty_tpl->tpl_vars['CATEGORIES_NAME']->value) {?><div class="description"><input type="checkbox" id="s_<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_ID'];?>
" name="products[]" value="<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_ID'];?>
" /> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_compare');?>
</div><?php }?>
			</div>
			</div>
			<div class="inner darken notop">
				<?php echo $_smarty_tpl->tpl_vars['module_data']->value['PRODUCTS_BUTTON_BUY_NOW_NEW'];?>

			</div>
		</li>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

	</ul>
</div>  
<!-- end: products listing -->  
<div class="clear"></div>

<?php if ($_smarty_tpl->tpl_vars['CATEGORIES_NAME']->value) {?>
<input type="hidden" name="cat" value="<?php echo $_GET['cat'];?>
" />
<?php echo $_smarty_tpl->tpl_vars['BUTTON_COMPARE']->value;?>
</form>
<?php }?>

<div class="navigation">
<span class="right"><?php echo $_smarty_tpl->tpl_vars['NAVIGATION']->value;?>
</span><?php echo $_smarty_tpl->tpl_vars['NAVIGATION_PAGES']->value;?>

</div>
<div class="clear"></div><?php }
}
