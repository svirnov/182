<?php
/* Smarty version 3.1.30, created on 2016-09-10 14:54:32
  from "C:\openserver\OpenServer\domains\www.182.ru\templates\vamshop1\module\shopping_cart.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57d3f478a7d8c2_45084768',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c564bffe185ece4f46b45672e18b710a3c572110' => 
    array (
      0 => 'C:\\openserver\\OpenServer\\domains\\www.182.ru\\templates\\vamshop1\\module\\shopping_cart.html',
      1 => 1472548002,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3f478a7d8c2_45084768 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['language']->value)."/lang_".((string)$_smarty_tpl->tpl_vars['language']->value).".conf", "shopping_cart", 0);
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'heading_cart');?>
</h1>
<?php if ($_smarty_tpl->tpl_vars['info_message']->value != '') {?>
<div class="contacterror"><?php echo $_smarty_tpl->tpl_vars['info_message']->value;?>
</div>
<?php }
echo $_smarty_tpl->tpl_vars['MODULE_gift_cart']->value;?>

<?php if ($_smarty_tpl->tpl_vars['cart_empty']->value == true) {?>
<div class="page">
<div class="pagecontent">

<p>
<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'text_empty');?>

</p>

</div>

<div class="pagecontentfooter">
<?php echo $_smarty_tpl->tpl_vars['BUTTON_CONTINUE']->value;?>

</div>
</div>
<p></p>
<?php } else {
echo $_smarty_tpl->tpl_vars['FORM_ACTION']->value;?>

<?php echo $_smarty_tpl->tpl_vars['HIDDEN_OPTIONS']->value;?>

<div class="page">
<div class="pagecontent">

<?php echo $_smarty_tpl->tpl_vars['MODULE_order_details']->value;?>

</div>

</div>

<?php if ($_smarty_tpl->tpl_vars['info_message_1']->value != '') {?>
<div class="contacterror">
<?php echo $_smarty_tpl->tpl_vars['info_message_1']->value;
echo $_smarty_tpl->tpl_vars['min_order']->value;
echo $_smarty_tpl->tpl_vars['info_message_2']->value;
echo $_smarty_tpl->tpl_vars['order_amount']->value;?>

</div>
<?php }?>

<div class="clear"></div>
<div class="navigation">
<span class="right"><?php echo $_smarty_tpl->tpl_vars['BUTTON_CHECKOUT']->value;?>
</span><?php echo $_smarty_tpl->tpl_vars['BUTTON_RELOAD']->value;?>

</div>
<div class="clear"></div>
<?php echo $_smarty_tpl->tpl_vars['MODULE_cross_selling_cart']->value;?>

<?php echo $_smarty_tpl->tpl_vars['FORM_END']->value;?>

<?php }
}
}
